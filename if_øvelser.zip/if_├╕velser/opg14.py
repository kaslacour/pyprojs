# Opgave 14: Simpel Lommeregner
# Skriv et program, der fungerer som en simpel lommeregner.
# Bed brugeren om at indtaste to tal og en operator (+, -, *, /).
# Udfør den tilsvarende operation og udskriv resultatet.
# Programmet skal håndtere division med nul og ukendte operatorer ved at udskrive passende fejlmeddelelser.

# Skriv din kode herunder:
