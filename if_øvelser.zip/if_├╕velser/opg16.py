# Opgave 16: Indkomstskat Beregner
# Skriv et program, der beregner indkomstskat baseret på følgende skattesatser:
# - Indkomst op til 50.000 kr.: 12%
# - Indkomst mellem 50.001 kr. og 100.000 kr.: 20%
# - Indkomst over 100.000 kr.: 30%
# Programmet skal bede brugeren om at indtaste sin årlige indkomst og derefter udskrive den samlede skat.

# Skriv din kode herunder:
