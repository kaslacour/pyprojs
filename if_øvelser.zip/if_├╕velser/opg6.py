# Opgave 6: Skudår?
# Skriv et program, der afgør, om et år er et skudår.

# Skriv din kode herunder: