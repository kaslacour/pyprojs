# Opgave 1: Positiv, negativ, eller bare nul?

# Programmet skal vurderer om et bruger-indtastet tal
# er positivt, negativt eller nul


# Ret i koden nedenfor:
tal = float(input("Indtast et tal: "))
if tal > 0:
    # Hvis tallet er større end nul, udskriv "Tallet er positivt."
    print("Tallet er nul")
elif tal < 0:
    # Hvis tallet er mindre end nul, udskriv "Tallet er negativt."
    print("Tallet er støre end nul")
else:
    # Ellers udskriv "Tallet er nul."
    print("Hello, world!")
