# Opgave 8: Temperaturkonvertering
# Skriv et program, der konverterer en temperatur fra Celsius til Fahrenheit eller Kelvin.
# Bed brugeren om at indtaste en temperatur i Celsius og vælge konvertering ('F' for Fahrenheit, 'K' for Kelvin).

# Skriv din kode herunder: