# Opgave 11: Kvadratisk Ligningsløser
# Skriv et program, der løser en kvadratisk ligning af formen ax^2 + bx + c = 0.
# Programmet skal bede brugeren om at indtaste værdierne for a, b og c.
# Derefter skal det beregne diskriminanten og bestemme antallet af reelle rødder.
# Udskriv rødderne, hvis de er reelle, eller giv en besked, hvis rødderne er komplekse.

# Skriv din kode herunder:
from math import sqrt