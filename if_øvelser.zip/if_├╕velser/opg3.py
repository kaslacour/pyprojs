# Opgave 3: Lige eller ulige? - Shakespeare
# Skriv et program, der beder brugeren om at indtaste et heltal.
# Programmet skal bestemme, om tallet er lige eller ulige, og udskrive resultatet.

# Skriv din kode herunder:
