# Opgave 5: Find det største tal
# Skriv et program, der beder brugeren om at indtaste tre tal.
# Programmet skal bestemme og udskrive det største af de tre tal.

# Skriv din kode herunder: