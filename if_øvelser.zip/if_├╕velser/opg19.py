# Opgave 19: Login System med Flere Brugere
# Udvid det simple loginsystem fra tidligere til at understøtte flere brugere.
# Opret en ordbog over gyldige brugernavne og adgangskoder
# Bed brugeren om at indtaste brugernavn og adgangskode.
# Tjek, om kombinationen er korrekt, og udskriv passende beskeder.

# Udfyl koden herunder:
brugere = {
    'admin': 'kode123',
    'bruger1': 'adgang1',
    'bruger2': 'adgang2',
}