# Opgave 9: Trekant med ben
# Trin 1: Bed brugeren om at indtaste længderne af tre sider i en trekant.
# Trin 2: Udskriv typen af trekanten: "ligesidet", "ligebenet", "forskelligbenet"

# Skriv din kode herunder: