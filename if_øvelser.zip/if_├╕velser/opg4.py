# Opgave 4: Det Amerikanske Karaktergivningssystem
# Skriv et program, der konverterer en numerisk karakter til en bogstavkarakter.

# Trin 1: Bed brugeren om at indtaste en karakter mellem 0 og 100.
# Trin 2: Konverter den til en bogstavkarakter baseret på følgende skala:
# 90-100: A
# 80-89: B
# 70-79: C
# 60-69: D
# 0-59: F


# Skriv din kode herunder