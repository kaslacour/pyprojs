# Opgave 18: Valutaomregner
# Skriv et program, der omregner et beløb fra danske kroner (DKK) til en anden valuta.
# Programmet skal tilbyde mindst tre valutaer (f.eks. Euro, USD, GBP) og bruge aktuelle vekselkurser.
# Bed brugeren om at indtaste beløbet i DKK og vælge valutaen til omregning.
# Udskriv det omregnede beløb.
# (For denne opgave kan du bruge faste vekselkurser.)

# Skriv din kode herunder: