# Opgave 10: Vokal eller konsonant?
# Skriv et program, der bestemmer, om et indtastet tegn er en vokal, en konsonant, eller hverken eller

# hint: 
# "k".isalpha() giver True, men "7".isalpha() giver False
# "A".lower() giver "a"

# Skriv din kode herunder: