# Opgave 7: Simpelt loginsystem
# Opret et program med et gemt brugernavn og adgangskode.
# Bed brugeren om at indtaste brugernavn og adgangskode.
# Udskriv "Login successful!" hvis oplysningerne matcher, ellers "Login failed."

gemt_brugernavn = "admin"
gemt_adgangskode = "kode123"

# Skriv din kode herunder:
