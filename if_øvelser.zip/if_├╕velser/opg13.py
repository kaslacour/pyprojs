# Opgave 13: Datoformat Validering
# Skriv et program, der beder brugeren om at indtaste en dato i formatet DD/MM/YYYY eller MM/DD/YYYY.
# Programmet skal afgøre, hvilket format der er brugt, baseret på værdierne, og udskrive datoen i det internationale format YYYY-MM-DD.
# Hvis datoen er ugyldig, skal programmet udskrive en fejlmeddelelse.

# Skriv din kode herunder:
# hint: "abc/def/ghi/jkl".split('/') giver listen [abc, def, ghi, jkl]