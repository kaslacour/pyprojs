personer = {}

while True:
    navn = input("Indtast navn (eller 'stop' for at afslutte): ")
    if navn == "stop":
        break
    alder = input("Indtast alder: ")
    
    try:
        # Konverter alder til et heltal
        alder = int(alder)
        # Tilføj navn og alder til ordbogen
        personer[navn] = 
    except ValueError:
        print("Ugyldig alder, prøv igen.")

# Udskriv listen over personer
for navn, alder in personer.items():
    print(navn, "er", alder, "år gammel")
