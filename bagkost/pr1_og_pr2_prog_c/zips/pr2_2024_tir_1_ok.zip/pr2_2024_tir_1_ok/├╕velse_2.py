# Gå igennem tallene fra 1 til 50
for tal in range(1, 51):
    # Tjek om tallet er deleligt med både 3 og 5
    if tal ... :
        print("FizzBuzz")
    # Tjek om tallet er deleligt med 3
    elif tal ... :
        print("Fizz")
    # Tjek om tallet er deleligt med 5
    elif tal ...:
        print("Buzz")
    else:
        print(tal)
