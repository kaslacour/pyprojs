# Bed brugeren om at indtaste tre tal
tal1 = input("Indtast det første tal: ")
tal2 = 
tal3 = 

# Konverter input til tal
tal1 = 
tal2 = float(tal2)
tal3 = 

# Beregn summen af de tre tal
sum = 

# Beregn gennemsnittet af de tre tal
gennemsnit = 

# Beregn produktet af de tre tal
produkt = 

# Vis resultaterne
print("Summen af de tre tal er:", )
print("Gennemsnittet af de tre tal er:")
print("Produktet af de tre tal er:")
